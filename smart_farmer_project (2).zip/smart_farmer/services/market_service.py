from database import get_db
def list_market_prices(crop=""):
    conn = get_db()
    rows = conn.execute(
        "SELECT id,crop_name,market_name,price,unit,distance_km,reported_at,source FROM market_prices WHERE crop_name LIKE ? ORDER BY crop_name,price DESC",
        (f"%{crop}%",)).fetchall()
    conn.close()
    return [dict(r) for r in rows]
