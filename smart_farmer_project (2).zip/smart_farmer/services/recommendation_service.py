from services.market_service import list_market_prices
def recommend_markets(crop, quantity, transport_cost_per_km, other_expenses=0):
    result = []
    for market in list_market_prices(crop):
        transport = market["distance_km"] * transport_cost_per_km
        gross = quantity * market["price"]
        result.append({**market, "quantity_kg": quantity, "estimated_transport_cost": round(transport,2),
            "other_expenses": round(other_expenses,2), "gross_amount": round(gross,2),
            "estimated_net_return": round(gross-transport-other_expenses,2)})
    return sorted(result, key=lambda x:x["estimated_net_return"], reverse=True)
