Optional images can be placed here. Homepage illustration is CSS-based.
