import os, tempfile, unittest
from app import app
from database import init_db
class SmartFarmerTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.NamedTemporaryFile(delete=False,suffix=".db"); self.tmp.close()
        app.config.update(TESTING=True,SECRET_KEY="test-secret",DATABASE_PATH=self.tmp.name,WTF_CSRF_ENABLED=False)
        with app.app_context(): init_db()
        self.client=app.test_client()
    def tearDown(self): os.unlink(self.tmp.name)
    def register(self,role="farmer",phone="9876543210"):
        return self.client.post("/api/register",json={"name":"Test Person","phone":phone,"password":"testpassword123","role":role,"location":"Karur"})
    def test_home_and_markets(self):
        self.assertEqual(self.client.get("/").status_code,200)
        self.assertGreater(len(self.client.get("/api/markets").get_json()),0)
    def test_duplicate_phone(self):
        self.assertEqual(self.register().status_code,201)
        self.assertEqual(self.register("buyer").status_code,409)
    def test_create_crop(self):
        self.register()
        r=self.client.post("/api/crops",json={"name":"Tomato","quantity":100,"expected_price":20,"harvest_date":"2026-11-01","quality_grade":"A","location":"Karur"})
        self.assertEqual(r.status_code,201)
    def test_calculator(self):
        r=self.client.post("/api/calculator",json={"quantity":100,"price":25,"transport_cost":300,"other_expenses":100})
        self.assertEqual(r.get_json()["net_amount"],2100.0)
if __name__=="__main__": unittest.main()
